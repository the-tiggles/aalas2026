### to make CSS/JS edits
- `npm install`
- `npm run build` and `npm run watch`
